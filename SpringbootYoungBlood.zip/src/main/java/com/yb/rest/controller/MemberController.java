package com.yb.rest.controller;

public class MemberController {

}
