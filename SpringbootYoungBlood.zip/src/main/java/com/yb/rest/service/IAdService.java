package com.yb.rest.service;

import java.util.List;

public interface IAdService {
	public List<String> getImgs(int id);
}
