package com.yb.rest.dao;

import java.util.List;

public interface IAdDao {
	public List<String> getImgs(int id);
	public List<String> getModalcontents(int id);
}
