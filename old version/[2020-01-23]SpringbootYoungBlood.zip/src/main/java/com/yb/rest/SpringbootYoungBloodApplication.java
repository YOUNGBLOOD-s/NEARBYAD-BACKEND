package com.yb.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootYoungBloodApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootYoungBloodApplication.class, args);
	}

}
